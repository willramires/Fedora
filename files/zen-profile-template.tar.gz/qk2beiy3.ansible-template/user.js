// Desativa o gerenciador de senhas nativo em favor do Proton Pass.
user_pref("signon.rememberSignons", false);
user_pref("signon.autofillForms", false);

// Mantem a interface em ingles e corrige a ortografia apenas em portugues.
user_pref("layout.spellcheckDefault", 2);
user_pref("spellchecker.dictionary", "pt-BR");
user_pref("intl.accept_languages", "en-US,en,pt-BR,pt");

// Nao abre a pagina de release notes apos atualizar o Zen/Firefox.
// As atualizacoes continuam habilitadas normalmente.
user_pref("browser.startup.homepage_override.mstone", "ignore");
