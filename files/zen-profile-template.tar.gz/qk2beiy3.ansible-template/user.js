// Desativa o gerenciador de senhas nativo em favor do Proton Pass.
user_pref("signon.rememberSignons", false);
user_pref("signon.autofillForms", false);

// Mantem a interface em ingles e corrige a ortografia apenas em portugues.
user_pref("layout.spellcheckDefault", 2);
user_pref("spellchecker.dictionary", "pt-BR");
user_pref("intl.accept_languages", "en-US,en,pt-BR,pt");

// Nao abre a pagina de release notes apos atualizar o Zen/Firefox.
// As atualizacoes continuam habilitadas normalmente.
user_pref("browser.startup.homepage_override.mstone", "ignore");

// Sem notificacao de atualizacao do Zen e extensoes do perfil ativas sem prompt.
user_pref("zen.updates.show-update-notification", false);
user_pref("extensions.autoDisableScopes", 0);
user_pref("extensions.enabledScopes", 5);

// Necessario para carregar chrome/userChrome.css.
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

user_pref("media.webspeech.synth.dont_notify_on_error", true);
