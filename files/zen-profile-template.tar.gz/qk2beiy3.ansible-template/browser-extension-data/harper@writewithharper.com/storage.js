{
  "defaultEnable": true,
  "isolateEnglish": true,
  "popupState": {
    "page": "main"
  }
}
